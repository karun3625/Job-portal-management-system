<div style="width:1048px; height:123px; background-color:#fff;border:solid 0px #F0F0F0;">

<div style="width:930px; height:20px; background-color:#FFFFFF; border:solid 0px #990000; margin-left:100px;">
<?php include('headermenu.php');?>
</div>

<div style=" width:1048px; height:70px; border:#339933 0px solid;">
<!--logo--><div style="width:740px; height:68px; float:left; border:solid 0px #FF0000; padding-top:2%;"><a href="index.php" style="text-decoration:none; font-size:22px;">PHPGURUKUL Job Portal</a></div>
<div style="width:300px; height:68px; border: 0px solid #000000; float:left;font-family:Monotype Corsiva; font-size:12px;">



</div>
</div>

<div style="width:450px; height:68px; border: 0px solid #000000; margin-left:670px; font-size:18px;"  >


<div style="width:105px; height:28px; padding-top:2px;  border-radius:10px 10px 0px 0px;border: 1px solid #fff; color:#FFFFFF; float:left; background-color:#000;" align="center">My Cart</div> 
 <div style="width:155px; height:28px;padding-top:2px;  border-radius:10px 10px 0px 0px;color:#FFFFFF;border: 1px solid #fff; float:left; background-color:#000; margin-left:10px;" align="center">Login / Register</div>
 
<div style="width:75px; height:28px;padding-top:2px; border-radius:10px 10px 0px 0px;color:#FFFFFF;border: 1px solid #fff; float:left; background-color:#000; margin-left:10px;" align="center">Help</div>
</div>
</div>